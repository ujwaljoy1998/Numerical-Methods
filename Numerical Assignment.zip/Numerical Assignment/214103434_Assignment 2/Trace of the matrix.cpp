#include<iostream>
#include<stdlib.h>
using namespace std;

int main()
{
	int i,j;
	double A[10][10],sum=0;
	cout<<"Matrix is: \n";
	for(i=0;i<=9;i++)
	{
		for(j=0;j<=9;j++)
		{
			A[i][j] = rand();
		}
	}
	for(i=0;i<=9;i++)
	{
		for(j=0;j<=9;j++)
		{
			cout<<A[i][j]<<"\t";
		}
		cout<<"\n";
	}
	for(i=0;i<=9;i++)
	{
		sum = sum + A[i][i];
	}
	cout<<"Trace of the matrix is: "<<sum;
	return 0;
}
