#include<iostream>
#include<conio.h>
#include<math.h>
using namespace std;

int main()
{
	int i,n ;
	double x,x_rad,f,sum,relative_error,exact_value;
	cout<<"Enter the value of x in degree\n";
	cin>>x;
	x_rad = (x*M_PI)/180;
	cout<<"Enter the number of terms upto which sin(x) needs to be expanded\n";
	cin>>n;
	f = x_rad;
	sum = x_rad;
	for(i=2;i<=n;i++)
	{
		f = f*(-(x_rad*x_rad)/(((2*i)-1)*((2*i)-2)));
		sum = sum + f;
	}
	cout<<"The value of sin(x) using Taylor Series expansion is: "<<sum<<"\n";
	exact_value = sin(x_rad);
	cout<<"The exact_value is: "<<exact_value<<"\n";
	relative_error = (sum - exact_value)/exact_value;
	relative_error = fabs(relative_error);
	cout<<"The relative error is: "<<relative_error<<"\n";
	return 0;
}
