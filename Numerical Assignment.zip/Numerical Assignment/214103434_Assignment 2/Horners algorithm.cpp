#include<iostream>
#include<conio.h>
#include<math.h>
using namespace std;

double fact(int f)
{
	int i,factorial;
	factorial=1;
	for(i=1;i<=f;i++)
	{
		factorial = factorial*i;
	}
	return factorial;
}

int main()
{
	int i,n,count,l,m,a,s;
	double A[25],B[25];
	double x,x_rad,sum;
	cout<<"Enter the number of terms upto which sin(x) needs to be expanded\n";
	cin>>n;
	cout<<"Enter the value in degree at which sin(x) needs to be evaluated\n";
	cin>>x;
	x_rad = (x*M_PI)/180;
	for(i=0;i<n;i++)
	{
		if(i%2==0)
		{
			A[i] = 0;
		}
		else
		{
			A[i] = 1/fact(i);
			if(i%4==3)
			{
				A[i] = (-1)*A[i];
			}
		}
	}
	B[n-1] = A[n];
	for(i=n-1;i>=0;i--)
	{
		B[i-1] = A[i] + (x_rad*B[i]);
		count = count + 2;
	}
	sum = A[0] + (x_rad*B[0]);
	cout<<"The value of polynomial is:"<<sum<<"\n";
	for(i=0;i<=n;i++)
	{
		if(A[i]==0)
		{
			l+=0;
		}
		else
		{
			l = l + i;
			m = m + 1;
		}
	}
	a = l + m - 1;
	s = a - count;
	cout<<"The difference in number of computation with the two methods are: "<<s;
}

