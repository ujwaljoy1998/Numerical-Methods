#include<iostream>
using namespace std;

int main()
{
	int i,j,m,n;
	double A[25][25],V[25],Product[25];
	cout<<"Enter the number of rows of the matrix\n";
	cin>>m;
	cout<<"Enter the number of columns of the matrix\n";
	cin>>n;
	cout<<"Enter the elements of the matrix row wise,ie,a11,a12,....\n";
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			cin>>A[i][j];
		}
	}
	cout<<"Enter the elements of the vector\n";
	for(j=0;j<n;j++)
	{
		cin>>V[j];
	}
	for(i=0;i<m;i++)
	{
		Product[i] = 0;
		for(j=0;j<n;j++)
		{
			Product[i] = Product[i] + (A[i][j]*V[j]);
		}
	}
	cout<<"Matrix vector multiplication is \n";
	for(i=0;i<m;i++)
	{
		cout<<Product[i]<<"\n";
	}
}
