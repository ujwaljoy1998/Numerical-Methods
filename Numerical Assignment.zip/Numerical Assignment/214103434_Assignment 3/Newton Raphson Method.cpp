
#include<iostream>
#include<math.h>

using namespace std;

double function(double x)			//Defining the function which needs to be evaluated
{
	double y;
	y = (x*exp(x)) - 1;
	return y;
}

double derivative(double x)			//Defining the derivative of the function which needs to be evaluated
{
	double z;
	z = (x*exp(x)) + exp(x);
	return z;
}int main()
{
	int i,N,Nmax;					//Defining iteration counter and maximum number of iterations
	double f1,f2,x1,x2,tol,e,h,error;
	double A[100];					//Defining an array to store the root in each iteration
	Nmax = 100;
	tol = pow(10,-6);				//Maximum tolerable error
	N = 1;
	e = 1;
	cout<<"Enter the initial guess\n";
	cin>>x1;
	f2 = derivative(x1);
	if(f2==0)						//Checking whether the value of derivative is 0 at the initial guess
	{
		cout<<"Please enter another initial guess";
	}
	do
	{
		f1 = function(x1);
		f2 = derivative(x1);
		h = f1/f2;
		x2 = x1 - h;				//Finding root in each iteration
		e = sqrt(pow(-h,2));
		A[N-1] = x2;				//Storing the root to an array
		x1 = x2;
		N = N + 1;
	}while((e>tol)&&(N<Nmax));
	cout<<"The root of the equation is: "<<x2<<"\n";
	cout<<"The total number of iterations are: "<<N-1<<"\n";
	for(i=0;i<N-1;i++)
	{
		error = fabs(A[i] - x2);		//Calculating error
		cout<<"Iteration number is "<<i+1<<"and error is "<<error<<"\n";
	}
}
