#include<iostream>
#include<math.h>

using namespace std;

double function(double x)                 
{
	double y;
	y = pow(x,2) - x - 2;
	return y;
}

int main()
{
	double a,b,fa,fb,tol,x,f1,e,x1,x2,y,z;
	tol = pow(10,-6);						
	e = 1;
	cout<<"Enter the initial guess of end point 1\n";
	cin>>a;
	cout<<"Enter the initial guess of end point 2\n";
	cin>>b;
	fa = function(a);						
	fb = function(b);
	if((fa*fb)>0)							
	{
		cout<<"Please enter another initial guess";
	}
	else
	{
		do
		{
			x = ((a*fb) - (b*fa))/(fb - fa);		
			f1 = function(x);
			if((f1*fb)<0)							
			{
				b = x;
				y = a/2;
				a = y;
			}
			else
			{
				a = x;
				z = b/2;
				b = z;
			}
			x1 = x;
			x2 = ((a*fb) - (b*fa))/(fb - fa);
			e = fabs(x2-x1);						
		}while(e>tol);
	cout<<"The root of the equation is\n"<<x;
	}
}

