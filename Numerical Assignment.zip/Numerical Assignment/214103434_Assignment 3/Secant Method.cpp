#include<iostream>
#include<math.h>

using namespace std;

double function(double x)			//Defining the function which needs to be evaluated
{
	double y;
	y = (x*exp(x)) - 1;
	return y;
}

int main()
{
	int i,N,Nmax;					//Defining iteration counter and maximum number of iterations
	double a,b,fa,fb,tol,f,x,e,error;
	double A[100];					//Defining an array to store the root in each iteration
	tol = pow(10,-6);				//Maximum tolerable error
	Nmax = 100;
	N = 1;
	cout<<"Enter the first guess which is smallest:\n";
	cin>>a;
	cout<<"Enter the second guess which is largest:\n";
	cin>>b;
	fa = function(a);
	fb = function(b);
	if(fa==fb)					//Checking whether function values are same at both the points
	{
		cout<<"Value of functions are same at both the points....Give other initial guess\n";
		exit(0);
	}
	do
	{
		fa = function(a);
		fb = function(b);
		if(fa==fb)					//Checking whether function values are same at both the points
		{
			cout<<"Value of functions are same at both the points....Give other initial guess\n";
			exit(0);
		}
		else
		{	x = b - (((b-a)*fb)/(fb-fa));		//Finding root in each iteration
			f = function(x);
			e = fabs(x-b);			//Finding error in each iteration
			A[N-1] = x;				//Storing the root to an array
			a = b;
			b = x;
			N = N + 1;
		}	
	}while((N<Nmax)&&(e>tol));
	cout<<"The root of the equation is: "<<x<<"\n";
	cout<<"Total number of iterations are: "<<N-1<<"\n";
	for(i=0;i<N-1;i++)
	{
		error = fabs(A[i]-x);		//Calculating error
		cout<<"Iteration number is "<<i+1<<" and error is: "<<error<<"\n";
	}
}

