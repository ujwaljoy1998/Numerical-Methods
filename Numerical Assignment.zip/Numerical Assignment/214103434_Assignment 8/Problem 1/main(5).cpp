#include <iostream>
#include<math.h>
#include<fstream>

using namespace std;

double func(double t)
{
    double f;
    f = 2 - (2*t) + 4*pow(t,2) - 4*pow(t,3) - (4*pow(t,4));
    return f;
}

int main()
{
	int i = 0;
    double k1,k2,k3,k4,y1,y,x,yn1,h,t1,t2,t3,t4;
    y1 = 1;
    x = 0;
    fstream output1;
    output1.open("output1.txt",ios::out);
    cout<<"Enter the step size\n";
    cin>>h;
  	for(i=0;i<=1/h;i++)
    {
        cout<<x<<"\t"<<y1<<"\n";
        output1<<x<<"\t"<<y1<<"\n";
        t1 = func(x);
        t2 = func(x-h);
        t3 = func(x-(2*h));
        t4 = func(x-(3*h));
        yn1 = y1 + ((h/24)*((55*t1) - (59*t2) + (37*t3) - (9*t4)));
        y1 = yn1;
        x = x + h;
    }
    output1.close();
	return 0;
}
