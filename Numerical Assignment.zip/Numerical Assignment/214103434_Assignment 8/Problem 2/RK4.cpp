#include <iostream>
#include<math.h>
#include<fstream>

using namespace std;

double func1(double u)
{
	return u;
}

double func2(double t, double y, double u)
{
	double a;
	a = (-4*u) + (2*y) + (2*pow(t,3)) -10;
	return a;
}

int main()
{
	double t,h,k1,k2,k3,k4,l1,l2,l3,l4,y1,u1,y,u,x;
	y1 = 0;
	u1 = 1;
	x = 0;
	h = 0.1;
	do
	{
		 cout<<x<<"\t"<<y1<<"\n";
		 k1 = h*func1(u1);
		 l1 = h*func2(x,y1,u1);
		 k2 = h*func1(u1+(l1/2));
		 l2 = h*func2((x+(h/2)),(y1+(k1/2)),(u1+(l1/2)));
		 k3 = h*func1(u1+(l2/2));
		 l3 = h*func2((x+(h/2)),(y1+(k2/2)),(u1+(l2/2)));
		 k4 = h*func1(u1+l3);
		 l4 = h*func2((x+h),(y1+k3),(u1+l3));
		 y = y1 + ((k1 + (2*k2) + (2*k3) + k4)/6);
		 u = u1 + ((l1 + (2*l2) + (2*l3) + l4)/6);
		 y1 = y;
		 u1 = u;
		 x = x + h;
	}while(x<=1);
	return 0;
}
