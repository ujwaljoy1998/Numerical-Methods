#include<iostream>
#include<math.h>
#include<fstream>

using namespace std;
double A[100][100],B[100],x[100];
int main()
{
	int i,j,k,Nmax = 10000,n,delta;
	double sum,tol,sum1,ri;
	for(i=0;i<100;i++)
	{
		x[i] = 1;
	}
	tol = pow(10,-6);
	fstream data_A;
	data_A.open("data_A.txt",ios::in);
	for(i=0;i<100;i++)
	{
		for(j=0;j<100;j++)
		{
			data_A>>A[i][j];
		}
	}

	fstream data_B;
	data_B.open("data_B.txt",ios::in);
	for(i=0;i<100;i++)
	{
		data_B>>B[i];
	}
	fstream Output;
	Output.open("Output.txt",ios::out);
	for (i=0;i<100;i++) 
	{                   //Pivotisation(partial) to make the equations diagonally dominant
        for (k=i+1;k<100;k++)
            {
				if (abs(A[i][i])<A[k][i])
                {
					for (j=0;j<=100;j++)
                	{
                    	double temp=A[i][j];
			            A[i][j]=A[k][j];
			            A[k][j]=temp;
                	}
                }
        	}
	}

do
{
	for(i=0;i<100;i++)
	{
		sum = 0;
		for(j=0;j<100;j++)
		{
			if(j!=i)
			{
				sum += A[i][j]*x[j];
			}
		}
		x[i] = (B[i] - sum)/A[i][i];
	}
	delta = 0;
	for(i=0;i<100;i++)
	{
		sum1 = 0;
		for(j=0;j<100;j++)
		{
			sum1 += A[i][j]*x[j];
		}
		ri = B[i] - sum1;
		delta = delta + pow(ri,2);
	}
	delta = sqrt(delta);
	n = n + 1;
}while((n<Nmax)&&(delta>tol));

for(i=0;i<100;i++)
{
	Output<<x[i]<<"\n";
}

return 0;
}
