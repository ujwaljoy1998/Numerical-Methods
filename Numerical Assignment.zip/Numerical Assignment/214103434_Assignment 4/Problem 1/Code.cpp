#include <iostream>
#include<math.h>
#include<fstream>
using namespace std;

int main()
{
    int i,j,k,n=49;
	double a,b,m,x[50][50],A[50][50],B[50][50],L[50][50],U[50][50],y[50][50];
	for(i=0;i<=n;i++)					//Entering matrix A
	{
		for(j=0;j<=n;j++)
		{
			if(i==j)
			{
				A[i][j] = 5;
			}
			else if(j==i+1)
			{
				A[i][j] = -1;
			}
			else if(j==i-1)
			{
				A[i][j] = -1;
			}
			else
			{
				A[i][j] = 0;
			}
		}
	}
	for(i=0;i<=n;i++)					//Entering matrix B
	{
		for(j=0;j<=n;j++)
		{
			if(i+j<50)
			{
				B[i][j] = i+j+1;
			}
			else
			{
				B[i][j] = i+j-n;
			}
		}
	}
	for(i=0;i<n;i++)					//LU factorization
	{
        m = A[i+1][i]/A[i][i];
        A[i+1][i] = m;
        A[i+1][i+1] = A[i+1][i+1]-(m*A[i][i+1]);
        
    }
    for(i=0;i<=n;i++)
	{
        for(int j=0;j<=n;j++)
		{
            if(i>j)
			{
                L[i][j]=A[i][j];
            }
            else if(i==j)
			{
				L[i][j]=1;
                U[i][j]=A[i][j];
            }
            else
			{
                U[i][j]=A[i][j];
            }
        }
    }

	for(k=0;k<=n;k++)				//Solving Ly = B and getting y values
	{	
		for(i=0;i<=n;i++)
    	{ 
    		if(i==0)
    		{
    			y[i][k] = B[i][k];
			}
			else
			{
				y[i][k] = B[i][k] - (L[i][i-1]*y[i-1][k]);
			}
    	}
	}
	for(k=0;k<=n;k++)			//Solving Ux = y and getting x values
	{
		for(i=n;i>=0;i--)
    	{
    		if(i==n)
    		{
    			x[i][k] = y[i][k]/U[i][i];
			}
			else
			{
					x[i][k] = (y[i][k] - (U[i][i+1]*x[i+1][k]))/U[i][i];
			}
		}
	}
	fstream Output1;
	Output1.open("Output1.txt",ios::out);
	for(i=0;i<=n;i++)						//Printing the result to output text file
	{Output1<<"\nThe Output for vector "<<i+1<<" is\n";
		for(k=0;k<=n;k++)
		{
			Output1<<x[k][i]<<"\t";
		}
	}
	return 0;
}
