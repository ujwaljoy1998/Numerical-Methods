#include<iostream>
#include<math.h>
#include<fstream>

using namespace std;

int main()
{
	int i,j,n=1,N=5;
	double A[N][N],B[N],x0[N],x[N],r[N],d[N],k[N],m,l[N],alpha,beta,Nmax=100000,tol,sum,sum1,t,numer,denom;
	fstream input_A;
	input_A.open("input_A.txt",ios::in);
	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			input_A>>A[i][j];
		}
	}
	for(i=0;i<N;i++)
	{
		B[i] = i+1;
	}
	tol = 0.000001;
	for(i=0;i<N;i++)
	{
		x0[i] = 0;
	}
	for(i=0;i<N;i++)
	{
		sum = 0;
		for(j=0;j<N;j++)
		{
			sum = sum + A[i][j]*x[j];
		}
		r[i] = B[i] - sum;
		d[i] = r[i];
	}
	do
	{
		t = 0;
		for(i=0;i<N;i++)
		{
			x0[i] = x[i];
		}
		denom = 0;
		numer = 0;
		for(i=0;i<N;i++)
		{
			numer = numer + r[i]*r[i];
			sum1 = 0;
			for(j=0;j<N;j++)
			{
				sum1 = sum1 + A[i][j]*d[j];
			}
			l[i] = sum1;
			denom = denom + d[i]*sum1;
		}
		
		alpha = numer/denom;
		
		for(i=0;i<N;i++)
		{
			x[i] = x[i] + (alpha*d[i]);
		}
		denom = 0;
		numer = 0;
		for(i=0;i<N;i++)
		{
			denom = denom + (d[i]*r[i]);
			r[i] = r[i] - (alpha*l[i]);
			numer = numer + (r[i]*r[i]);
		}
		beta = numer/denom;
		for(i=0;i<N;i++)
		{
			d[i] = r[i] + (beta*d[i]);
		}
		for(i=0;i<N;i++)
		{
			k[i] = x[i] - x0[i];
			t = t + pow(k[i],2);
		}
		m = sqrt(t);
		
		n = n + 1;
	}while((n<Nmax)&&(m>tol));
	for(i=0;i<N;i++)
	{
		cout<<x[i]<<"\n";
	}
	cout<<"Number of iterations are:\n"<<n;	
}
