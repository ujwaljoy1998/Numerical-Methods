#include<iostream>
#include<math.h>
#include<fstream>

using namespace std;

int main()
{
	int i,j,Nmax=10000,n=0,delta,N=5;
	double A[5][5],B[5],x0[5],x[5],sum=0,sum1=0,tol,ri,m;
	tol = pow(10,-6);
	fstream input_A;
	input_A.open("input_A.txt",ios::in);
	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			input_A>>A[i][j];
		}
	}
	for(i=0;i<N;i++)
	{
		B[i] = i+1;
	}
	for(i=0;i<N;i++)
	{
		x0[i] = 0;
	}
do
{
	for(i=0;i<N;i++)
	{
		sum = 0;
		for(j=0;j<N;j++)
		{
			if(j!=i)
			{
				sum += A[i][j]*x0[j];
			}
		}
		x[i] = (B[i] - sum)/A[i][i];
	}
	delta = 0;
	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			sum1 += A[i][j]*x[j];
		}
		ri = B[i] - sum1;
		delta += pow(ri,2);
	}
	m = sqrt(delta);
	n = n + 1;
	for(i=0;i<N;i++)
	{
		x0[i] = x[i];
	}
}while((n<Nmax)&&(m>tol));
for(i=0;i<N;i++)
{
	cout<<x[i]<<"\n";
}
cout<<n;
}
