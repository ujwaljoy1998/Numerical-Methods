#include<iostream>
#include<math.h>
#include<fstream>
using namespace std;

int main()
{
int i,j,k=0,N=4,Nmax;
double x1[4],x2[4],A[4][4],t[4],m=0,y=0,a=0,mu,z=0,tol,sum;
fstream input;
input.open("input.txt",ios::in);
for(i=0;i<N;i++)
{
	for(j=0;j<N;j++)
	{
		input>>A[i][j];
	}
} 
tol = 0.000001;
Nmax = 10000;
for(i=0;i<N;i++)
{
	x1[i] = i+1;
}
for(i=0;i<N;i++)
{
	if(fabs(x1[i])>m)
	{
		m = fabs(x1[i]);
	}
}
for(i=0;i<N;i++)
{
	x1[i] = x1[i]/m;
}
do
{
	y=0;
	z=0;
	for(i=0;i<N;i++)
	{
		sum = 0;
		for(j=0;j<N;j++)
		{
			sum = sum + A[i][j]*x1[j];
		}
		x2[i] = sum;
	}
	for(i=0;i<N;i++)
	{
		if(fabs(x2[i])>y)
		{
			y = fabs(x2[i]);
		}
	}
	mu = y;
	if(y==0)
	{
		cout<<"A has zero eigen value. Restart with new guess";
		break;
	}
	for(i=0;i<N;i++)
	{
		t[i] = x1[i] - (x2[i]/y);
	}
	for(i=0;i<N;i++)
	{
		if(fabs(t[i])>z)
		{
			z = fabs(t[i]);
		}
	}
	for(i=0;i<N;i++)
	{
		x1[i] = x2[i]/y;
	}
	if(z<tol)
	{
		cout<<"Eigen value is "<<mu<<"\n";
		cout<<"Eigen vector is\n";
		for(i=0;i<N;i++)
		{
			cout<<x1[i]<<"\n";
		}
		break;
	}
	k = k + 1;
	}while(k<Nmax);
return 0;
}
