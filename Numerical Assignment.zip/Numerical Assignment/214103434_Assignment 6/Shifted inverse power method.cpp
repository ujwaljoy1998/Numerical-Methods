#include<iostream>
#include<math.h>
#include<fstream>
using namespace std;

int main()
{
	int i,j,k,N=4,n=1,pos,Nmax;
	double A[10][10],A1[10],x1[10],x[10],y[10],e[10],m,z,q,l,s,mu,del=1,TOL=0.000001;
	fstream input;
	input.open("input.txt",ios::in);
	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			input>>A[i][j];
		}
	}
	Nmax = 10000;
	for(i=0;i<N;i++)
	{
		x1[i] = 1;
	}
	q = 0;
	for(i=0;i<N;i++)
	{
		A[i][i] = A[i][i] - q;
	}
	m=fabs(x1[0]);
	for(i=0;i<N;i++)
	{
		if(fabs(x1[i])>m)
		{
			m = (x1[i]);
			pos = i;
		}
	}
	for(i=0;i<N;i++)
	{
		x1[i] = x1[i]/m;
	}

	
	do
	{
		for(i=0;i<N;i++)
		{
			x[i] = x1[i];
		}
	for(int k=0;k<N-1;k++){
            for(int i=k+1;i<N;i++){
                for(int j=k;j<N;j++){
                    if(n==1){
                       A[i][j]=A[i][j] - (A[k][j]/A[k][k])*A[i][k];
                    }
                    else{
                        break;
                    }
                }
                x[i]=x[i]-(A[i][k]/A[k][k])*x[k];
            }
        }
        y[N-1]=x[N-1]/A[N-1][N-1];
        for(int k=N-2;k>=0;k--){
            s=0;
            for(int j=k+1;j<n;j++){
                s=s+A[k][j]*y[j];
            }
            y[k]=(x[k]-s)/A[k][k];
    }
 		m=fabs(y[0]);
 		for(i=0;i<N;i++)
 		{
 			if(fabs(y[i])>m)
 			{
 				m=y[i];
 				pos=i;
			 }
		 }
        mu = y[pos];
     
		del=0;
		for(i=0;i<N;i++)
		{
			del=del+pow((y[i]/mu-x[i]),2);
		}
		del=sqrt(del);
		for(i=0;i<N;i++)
		{
			x1[i] = y[i]/mu;
		}
		n = n + 1;
		
	}while(n<Nmax&&del>TOL);
	l = q + (1/mu);
	cout<<"The smallest eigen value\n"<<l;
}
