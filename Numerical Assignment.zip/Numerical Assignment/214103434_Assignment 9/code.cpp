#include <iostream>
#include <math.h>

using namespace std;

double func1(double u)
{
    return u;
}

double func2(double x, double y,double u)
{
    double f;
    f = 4 + (pow(x,3)/4) - ((y*u)/8);
    return f;
}

double func3(double v)
{
    return v; 
}

double func4(double y, double z, double v,double w)
{
    double f;
    f = -(z*v +y*w)/8;
    return f;
}

double exact(double x)
{
	double f;
    f = pow(x,2) + 16/x;
    return f;
}

int main()
{
	 int i;
     double x1,x2,y1,y2,z,x,y,xe,h,m,v,w,k11,k12,k13,k14,l11,l12,l13,l14,k21,k22,k23,k24,l21,l22,l23,l24,tol,n,l;
     double Y[25];
     x1 = 1;
     x2 = 3;
     y1 = 17;
     y2 = 43/3;
     m = 15;
     n=20;
     h=(x2-x1)/n;
     Y[0]=y1;

    do{
        z=m;
        x=x1;
        y=y1;
        v=0;
        w=1;
        for(i =1;i<=n;i++)
		{
         k11=h*func1(z);
         l11=h*func2(x,y,z);
         k12=h*func1(z+l11/2);
         l12=h*func2(x+h/2,y+k11/2,z+l11/2);
         k13=h*func1(z+l12/2);
         l13=h*func2(x+h/2,y+k12/2,z+l12/2);
         k14=h*func1(z+l13);
         l14=h*func2(x+h,y+k13,z+l13);
         y=y+(k11+2*(k12+k13)+k14)/6;
         z=z+(l11+2*(l12+l13)+l14)/6;
         
         k21=h*func3(w);
         l21=h*func4(y,z,v,w);
         k22=h*func3(w+l21/2);
         l22=h*func4(y,z,v+k21/2,w+l21/2);
         k23=h*func3(w+l22/2);
         l23=h*func4(y,z,v+k22/2,w+l22/2);
         k24=h*func3(w+l23);
         l24=h*func4(y,z,v+k23,w+l23);
         v=v+(k21+ 2*(k22+k23)+k24)/6;
         w=w+(l21+ 2*(l22+l23)+l24)/6;
         x = x + h;
         Y[i]=y;
         }
         m = m - (y-y2)/v;
    }while(fabs(y-y2)>tol);
    xe = x1;
    cout<<"Shooting Method\t\t\tExact Value\n";
    for(i=0;i<=n;i++)
    {
    	l = exact(xe);
        cout<<Y[i]<<"\t\t\t\t"<<l<<"\n";
        xe = xe + h;
    }
    return 0;
}
