#include<iostream>
using namespace std;

class complex
{
	public:
		float real,imaginary;
		complex(float m = 0, float n = 0)
		{
			real = m;
			imaginary = n;
		}
		complex addcomplex(complex C1, complex C2)
		{
			complex a;
			a.real = C1.real + C2.real;
			a.imaginary = C1.imaginary + C2.imaginary;
			return a;
		}
		complex subtractcomplex(complex C1, complex C2)
		{
			complex b;
			b.real = C1.real - C2.real;
			b.imaginary = C1.imaginary - C2.imaginary;
			return b;
		}
		complex multiplycomplex(complex C1, complex C2)
		{
			complex c;
			c.real = C1.real*C2.real - C1.imaginary*C2.imaginary;
			c.imaginary = C1.real*C2.imaginary + C1.imaginary*C2.real;
			return c;
		}
		complex conjugate(complex C1)
		{
			complex d;
			d.real = C1.real;
			d.imaginary = C1.imaginary;
			return d;
		}
};
int main()
{
	complex C1,C2;
	cout<<"Enter the real part of first complex number\n";
	cin>>C1.real;
	cout<<"Enter the imaginary part of first complex number\n";
	cin>>C1.imaginary;
	cout<<"Complex number 1 is:"<<C1.real<<" + "<<C1.imaginary<<"i\n";
	cout<<"Enter the real part of second complex number\n";
	cin>>C2.real;
	cout<<"Enter the imaginary part of second complex number\n";
	cin>>C2.imaginary;
	cout<<"Complex number 2 is:"<<C2.real<<" + "<<C2.imaginary<<"i\n";
	complex C3,C4,C5,C6;
	C3 = C3.addcomplex(C1,C2);
	cout<<"Sum is: "<<C3.real<<" + "<<(C3.imaginary)<<"i\n";
	C4 = C4.subtractcomplex(C1, C2);
	cout<<"Subtraction is: "<<C4.real<<" + "<<(C4.imaginary)<<"i\n";
	C5 = C5.multiplycomplex(C1,C2);
	cout<<"Multiplication is: "<<C5.real<<" + "<<(C5.imaginary)<<"i\n";
	C6 = C6.conjugate(C1);
	cout<<"Conjugate of first complex number is: "<<C6.real<<" - "<<(C6.imaginary)<<"i";
}
