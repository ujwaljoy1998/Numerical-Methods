#include<iostream>
using namespace std;

int main()
{
	double x,y;
	cout<<"Enter the value of epsilon\n";
	cin>>y;
	while((1+y)!=1)
	{
		x = y;
		y = y/2;
	}
	cout<<"Machine Epsilon is : "<<x;
	return 0;
}
