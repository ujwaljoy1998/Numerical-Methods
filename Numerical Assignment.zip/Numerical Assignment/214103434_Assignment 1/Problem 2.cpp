#include<iostream>
using namespace std;

int main()
{
	int i,first_num=0,second_num=1,next_num;
	cout<<first_num<<" "<<second_num<<" ";
	for(i=2;i<20;i++)
	{
		next_num = first_num + second_num;
		cout<<next_num<<" ";
		first_num = second_num;
		second_num = next_num;
	}
	return 0;
}
